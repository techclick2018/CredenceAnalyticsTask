from flask import Flask, jsonify,render_template
import pymongo


myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["MovieDetails"]
mycol = mydb["MovieList"]

api = Flask(__name__)

@api.route('/index', methods=['GET'])
def get_list():
  # return jsonify(data)
  mlist = mycol.find().limit(10)
  return render_template("index.html", mlist = mlist)

if __name__ == '__main__':
    api.run(debug=True)